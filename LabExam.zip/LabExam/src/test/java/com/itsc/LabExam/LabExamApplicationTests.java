package com.itsc.LabExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
