package com.itsc.bookInventory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class BookRepo {
    private String dtName = "bookDatabase";
    private String tName = "reference_books";
    private String use = "USE " + dtName;
    private String createDB = "CREATE DATABASE " + dtName;
    private String createTable = "CREATE TABLE " + tName + " (id int auto_increment primary key, title varchar(255), author varchar(255))";

    public String url = "jdbc:mysql://localhost:3306/?user=root";
    public String username = "root";
    public String password = "qwerty";

    public void createDBAndTable() {
        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            statement.executeUpdate(createDB);
            statement.executeUpdate(use);
            statement.executeUpdate(createTable);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insertIntoTable(Book book) {
        String insertData = "INSERT INTO " + tName + " (title, author) VALUES (?, ?)";
        try {
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            statement.executeUpdate(use);
            PreparedStatement preparedStatement = connection.prepareStatement(insertData);
            preparedStatement.setString(1, book.getTitle());
            preparedStatement.setString(2, book.getAuthor());
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
